<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/AutentificadorJWT.php';

require_once './clases/Usuarios.php';
require_once './clases/Empleado.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

////USAR APRA AUTENTICACION ULTIMA LINEA           })->add($mdwAuth);

$app = new \Slim\App(["settings" => $config]);

$app->group('/usuarios', function () 
{
    $this->get('[/]', function (Request $request, Response $response) {    
        $response->getBody()->write("GET => Bienvenido!!! ,a SlimFramework");
        return $response;
    
    });
    
    //************ LOGIN ************//
    $this->post('/login', function (Request $request, Response $response) {
        $datos = $request->getParsedBody();
        $mail = $datos["mail"];
        $password = $datos["password"];
        $newResponse = $response->withJson(Usuarios::login($mail,$password));
        //$response->write($pw);
        return $newResponse;
    });
    
    //************ AUTENTICACION ************//
    $mdwAuth = function ( $request, $response, $next) {
        $token = $request->getHeader('token');
        if(AutentificadorJWT::verificarToken($token[0])){
            $response = $next($request,$response);
        }  
        return $response;
    };
    
    //************ TOKEN ************//
    $this->post('/crearToken', function (Request $request, Response $response) {
        $datos = $request->getParsedBody();
        //$datos = array('usuario' => 'rogelio@agua.com','perfil' => 'profe', 'alias' => "PinkBoy");
        $token= AutentificadorJWT::CrearToken($datos); 
        $newResponse = $response->withJson($token, 200); 
        return $newResponse;
    });
    
    ////revisar!
    $this->post('/leerHeader', function (Request $request, Response $response) {
        $datos = $request->getParsedBody();
        $header = $request->getHeader('miHeader');
        $leido = AutentificadorJWT::ObtenerPayLoad($header);
        var_dump($leido);
        $newResponse = $response->withJson($header, 200); 
        return $newResponse;
    });
    //************************//
    
    //************ EMPLEADOS ************//
    
    //AGREGAR EMPLEADO  *************************/
    $this->post('/Alta',\Empleado::class . ':Alta');
    
    //TRAER TODOS LOS EMPLEADOS *************************/
    $this->post('/TraerTodos',\Empleado::class . ':TraerTodos')->add($mdwAuth);
    
    //TRAER EMPLEADO POR LEGAJO *************************/
    $this->post('/TraerPorLegajo',\Empleado::class . ':TraerPorLegajo')->add($mdwAuth);
    
    
    //MODIFICAR EMPLEADO *************************/
    $this->post('/Modificar',\Empleado::class . ':Modificar')->add($mdwAuth);
    
    //BORRAR EMPLEADO *************************/
    $this->post('/Borrar',\Empleado::class . ':Borrar')->add($mdwAuth);
});
    

$app->run();
