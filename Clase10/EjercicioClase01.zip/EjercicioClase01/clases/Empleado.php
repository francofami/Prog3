<?php

require_once 'IApiEmpleado.php';
require_once 'Usuarios.php';

class Empleado implements IApiEmpleado
{
    private $legajo;
    private $nombre;
    private $mail;
    private $clave;
    private $sexo;
    private $apellido;
    private $foto;
    private $sueldo;
    private $dni;


    //AGREGAR Usuario
    public static function Alta($request, $response, $args)
    { 
        $datos = $request->getParsedBody();
    
        //Aca debo recibir un json que contenga legajo,nombre,mail,... y despues desgranarlo

        $jsonDatos = $datos['jsonDatos'];
        $empleado = json_decode($jsonDatos);
        
        $fotos = $request->getUploadedFiles();
        $nombreFoto = $fotos["foto"]->getClientFileName();
        $ubicacionFoto = "./fotos/".date("dis")."_".$empleado->legajo.".jpg";
        $fotos["foto"]->moveTo($ubicacionFoto);
        
        $legajo = $empleado->legajo;
        $nombre = $empleado->nombre;
        $mail = $empleado->mail;
        $clave = password_hash($empleado->clave, PASSWORD_BCRYPT);
        $sexo = $empleado->sexo;
        $apellido = $empleado->apellido;
        $foto = $ubicacionFoto;
        $sueldo = $empleado->sueldo;
        $dni = $empleado->dni;
    
        if(Usuarios::verificarMail($mail)){
            //$response->write(usuario::agregarUsuario($mail,$password,$nombre,$apellido,$tipo));
            //$id_usuario=$response->write(Empleado::Alta($legajo, $nombre, $mail, $clave, $sexo, $apellido, $foto, $sueldo, $dni));  

            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
            $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into  
            usuarios (legajo, nombre, mail, clave, sexo, apellido, foto, sueldo, dni)
            values(:legajo, :nombre, :mail, :clave, :sexo, :apellido, :foto, :sueldo, :dni)");

            $consulta->bindValue(':legajo',$legajo);
            $consulta->bindValue(':nombre', $nombre);
            $consulta->bindValue(':mail',$mail);
            $consulta->bindValue(':clave', $clave);
            $consulta->bindValue(':sexo', $sexo);
            $consulta->bindValue(':apellido',$apellido);
            $consulta->bindValue(':foto',$foto);
            $consulta->bindValue(':sueldo',$sueldo);
            $consulta->bindValue(':dni',$dni);

            $consulta->execute();
        }
        else{
            $newResponse = $response->withJson('Mail en uso');
            return $newResponse;
        }
  
        /*
        
            Retorno JSON con Exito = true, false
            Mensaje: Se pudo, no se pude blablabla
            Status: 200, 401, etc
        */

        //$response->withJson(['exito' => true, 'mensaje' => 'todo bien',])->withStatus(200));

        return 1;
    }
   

    //TRAER TODOS LOS clientes
    public static function TraerTodos($request, $response, $args)
    {


        //$response->write(Empleado::TraerTodos());



        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * 
        FROM usuarios");
        
        $consulta->execute();
        $consulta = $consulta->fetchAll(PDO::FETCH_ASSOC);
        return json_encode($consulta);
    }

    //TRAER cliente POR ID
    public static function TraerPorLegajo($request, $response, $args)
    {


        $datos = $request->getParsedBody();
        $legajo = $datos['legajo'];
        //$response->write(Empleado::TraerPorLegajo($legajo));




        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * 
        FROM usuarios WHERE id=$id");

        $consulta->bindValue(":id",$id);
        $consulta->execute();
        $datos = $consulta->fetchAll(PDO::FETCH_ASSOC);
        return json_encode($datos);     
    }

   //MODIFICAR cliente
    public static function Modificar($request, $response, $args)
    {




        $datos = $request->getParsedBody();
        $legajo = $datos['legajo'];
        $nombre = $datos['nombre'];
        $mail = $datos['mail'];
        $clave = $datos['clave'];
        $sexo = $datos['sexo'];
        $apellido = $datos['apellido'];
        $foto = $datos['foto'];
        $sueldo = $datos['sueldo'];
        $dni = $datos['dni'];
        //$response->write(Empleado::Modificar($legajo, $nombre, $mail, $clave, $sexo, $apellido, $foto, $sueldo, $dni));





        $rta = false;
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE usuarios 
        SET legajo=:legajo,
        nombre=:nombre,
        mail=:mail,
        clave=:clave,
        sexo=:sexo,
        telefono=:telefono,
        apellido=:apellido,
        foto=:foto,
        sueldo=:sueldo,
        dni=:dni
        WHERE id=$id");

        $consulta->bindValue(':legajo',$legajo);
        $consulta->bindValue(':nombre', $nombre);
        $consulta->bindValue(':mail',$mail);
        $consulta->bindValue(':clave', $clave);
        $consulta->bindValue(':sexo', $sexo);
        $consulta->bindValue(':apellido',$apellido);
        $consulta->bindValue(':foto',$foto);
        $consulta->bindValue(':sueldo',$sueldo);
        $consulta->bindValue(':dni',$dni);

        if ($consulta->execute()){
            $rta = true;
        }

        //La foto vieja antes de ser modificada quedara guardada en fotos/Modificadas/

        return $rta;
    }

    //BORRAR cliente
    public static function Borrar($request, $response, $args)
    {




        $datos = $request->getParsedBody();
        $id = $datos['id'];
        //$response->write(Empleado::Borrar($id));






        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("DELETE FROM usuarios WHERE id_usuario=:id");
        $consulta->bindValue(":id",$id);

        //La foto borrada quedara en fotos/Eliminadas/

        return $consulta->execute();      
    }
 
}
?>