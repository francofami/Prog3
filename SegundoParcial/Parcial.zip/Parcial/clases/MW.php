<?php

require_once 'AccesoDatos.php';
require_once 'AutentificadorJWT.php';

class MW
{
    public function MdwLoginSeteado($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        //var_dump($datos);

        if(isset($datos['jsonDatos']) && !empty($datos))
        {
            $newResponse = $next($request, $response);
        }
        else
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, datos no seteados."], 403);
        }
        
        return $newResponse;
    }

    public static function MdwLoginVacio($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        $jsonDatos = $datos['jsonDatos'];
        $usuario = json_decode($jsonDatos);

        if(strlen($usuario->correo) == 0 || strlen($usuario->clave) == 0)
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, datos vacios."], 409);
        } 
        else
        {
            $newResponse = $next($request, $response);
        }

        return $newResponse;
    }

    public function MdwVerificarBaseDeDatos($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        $jsonDatos = $datos['jsonDatos'];
        $usuario = json_decode($jsonDatos);

        $usuarioCompleto = Usuarios::traerUsuarioPorEmailClave($usuario);

        if(empty($usuarioCompleto))
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, el mail y clave no se encuentran en nuestra base de datos."], 403);
        }
        else
        {
            $newResponse = $next($request, $response);
        }

        return $newResponse;
    }

    public static function MdwVerificarMailBaseDeDatos($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $jsonDatos = $datos['jsonDatos'];
        $usuario = json_decode($jsonDatos);

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE correo=:correo");

        $consulta->bindValue(":correo",$usuario->correo);
        $consulta->execute();
        
        if($consulta->fetchAll(PDO::FETCH_ASSOC))
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, el mail ya existe."], 403);
        }
        else
        {
            $newResponse = $next($request, $response);
        }

        return $newResponse;  
    }

    public function VerificarToken($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $jwt = $datos['jwt'];

        if(AutentificadorJWT::VerificarToken($jwt))
        {
            $newResponse = $next($request, $response);
        }
        else
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, token invalido."], 403);
        }

        return $newResponse;
    }

    public function MdwVerificarPrecioColor($request, $response, $next)
    {   
        $flagPrecio = 0;
        $flagColor = 0;

        $datos = $request->getParsedBody();
        $jsonDatos = $datos['jsonDatos'];
        $auto = json_decode($jsonDatos);

        $jsonRespuesta = new StdClass();

        if($auto->precio<50000 || $auto->precio > 600000)
        {
            $flagPrecio = 1;  
        }

        if(strtolower($auto->color) == "azul")
        {
            $flagColor = 1;
        }

        if($flagPrecio==1 && $flagColor==0)
        {
            $jsonRespuesta->Mensaje = "El precio del auto debe estar entre 50000 y 600000.";
        }
        else if($flagPrecio==0 && $flagColor ==1)
        {
            $jsonRespuesta->Mensaje += "El auto no debe ser de color azul.";
        }
        else if($flagPrecio==1 && $flagColor ==1)
        {
            $jsonRespuesta->Mensaje = "El precio del auto debe estar entre 50000 y 600000 y el auto no debe ser de color azul.";
        }

        $newResponse = $response->withJson($jsonRespuesta, 409);
        
        if($flagPrecio==0 && $flagColor ==0)
        {   
            $newResponse = $next($request, $response);
        }

        return $newResponse;
    }

    public static function MdwVerificarPropietario($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $jwt = $datos['jwt'];
        $jsonRespuesta = new StdClass();

        $user = AutentificadorJWT::DecodificarToken($jwt);

        if(strtolower($user->perfil)=="propietario")
        {
            $jsonRespuesta->propietario = true;
            $jsonRespuesta->mensaje = "El usuario es propietario";
            $newResponse = $response->withJson($jsonRespuesta, 200);
            //$newResponse = $next($request, $response->withJson($jsonRespuesta, 200));
        }
        else
        {
            $jsonRespuesta->propietario = false;
            $jsonRespuesta->mensaje = "El usuario no es propietario";
            $newResponse = $response->withJson($jsonRespuesta, 409);
            //$newResponse = $next($request, $response->withJson($jsonRespuesta, 409));
        }
    }

    public function MdwVerificarEncargado($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $jwt = $datos['jwt'];
        $jsonRespuesta = new StdClass();

        $user = AutentificadorJWT::DecodificarToken($jwt);

        if(strtolower($user->perfil)=="encargado")
        {
            $jsonRespuesta->encargado = true;
            $jsonRespuesta->mensaje = "El usuario es encargado";
            $newResponse = $response->withJson($jsonRespuesta, 200);
        }
        else
        {
            $jsonRespuesta->encargado = false;
            $jsonRespuesta->mensaje = "El usuario no es encargado";
            $newResponse = $response->withJson($jsonRespuesta, 409);
        }
    }
}