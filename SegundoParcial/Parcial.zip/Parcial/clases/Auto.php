<?php

require_once 'AccesoDatos.php';
require_once 'AutentificadorJWT.php';


class Auto
{
    public static function Alta($request, $response, $args)
    { 
        $datos = $request->getParsedBody();

        $jsonDatos = $datos['jsonDatos'];
        $auto = json_decode($jsonDatos);
        
        $color = $auto->color;
        $marca = $auto->marca;
        $precio = $auto->precio;
        $modelo = $auto->modelo;

        $json = new stdClass();  
        
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into  
        autos (color, marca, precio, modelo)
        values(:color, :marca, :precio, :modelo)");

        $consulta->bindValue(':color',$color);
        $consulta->bindValue(':marca', $marca);
        $consulta->bindValue(':precio', $precio);
        $consulta->bindValue(':modelo', $modelo);

        if($consulta->execute())
        {
            $json->exito=true; 
            $json->mensaje="OK"; 

            $newResponse = $response->withJson($json, 200);
        }
        else
        {
            $json->exito=false; 
            $json->mensaje="Error."; 

            $newResponse = $response->withJson($json, 418);
        }      

        return $newResponse;
    }

    public static function Listado($request, $response, $args)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT color, marca, precio, modelo FROM autos");
        
        $consulta->execute();

        $json = new stdClass();  

        if($consulta->setFetchMode(PDO::FETCH_ASSOC))
        {
            $retorno="<table border='1' style='width:0%;height:0%'><tr><th>Color</th><th>Marca</th><th>Precio</th><th>Modelo</th></tr>";


            while($auto=$consulta->fetch()){
                $retorno.="<tr><td>".$auto["color"]."</td><td>".$auto["marca"]."</td><td>".$auto["precio"]."</td><td>".$auto["modelo"]."</td></tr>";
            }
            $retorno.="</table>";

            $json->exito=true; 
            $json->mensaje="OK";
            $json->tabla = $retorno;
             

            $newResponse = $response->withJson($json, 200);
        }
        else
        {
            $json->exito=false; 
            $json->mensaje="Error.";
            $json->tabla = "";

            $newResponse = $response->withJson($json, 424);
        }

        //echo $json->tabla;

        return $newResponse;
    }

    public static function Eliminar($request, $response, $args)
    {
        $jsonRespuesta = new StdClass();
        $datos = $request->getParsedBody();    

        $id = $datos['id'];
        $jwt = $datos['jwt'];

        $user = AutentificadorJWT::DecodificarToken($jwt);

        if(strtolower($user->perfil)=="propietario")
        {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

            $consulta =$objetoAccesoDato->RetornarConsulta("DELETE FROM autos WHERE id = :idAct");

            $consulta->bindValue(':idAct', $id, PDO::PARAM_STR);  //PDO::PARAM_STR String
            $consulta->execute();
            
            if($consulta->rowCount() > 0) 
            {
                $jsonRespuesta->exito = true;
                $jsonRespuesta->mensaje = "Auto eliminado.";
                $newResponse = $response->withJson($jsonRespuesta, 200);
            }
            else
            {
                $jsonRespuesta->exito = false;
                $jsonRespuesta->mensaje = "Ocurrió un error al intentar eliminar el auto.";
                $newResponse = $response->withJson($jsonRespuesta, 418);
            }
        }
        else
        {
            $jsonRespuesta->exito = false;
            $jsonRespuesta->mensaje = $user->apellido." ".$user->nombre." se quiso pasar de listo eliminando un auto.";
            
            $newResponse = $response->withJson($jsonRespuesta, 418);
        }

        return $newResponse;
    }


    public static function Modificar($request, $response, $args)
    {
        $jsonRespuesta = new StdClass();
        $datos = $request->getParsedBody();    

        $jsonDatos = $datos['jsonDatos'];
        $auto = json_decode($jsonDatos);
        $jwt = $datos['jwt'];

        $user = AutentificadorJWT::DecodificarToken($jwt);

        if(strtolower($user->perfil)=="propietario" || strtolower($user->perfil)=="encargado")
        {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

            $consulta =$objetoAccesoDato->RetornarConsulta("UPDATE autos SET color = :color, marca = :marca, precio = :precio, modelo = :modelo WHERE id = :id");

            $consulta->bindValue(':color', $auto->color, PDO::PARAM_STR);
            $consulta->bindValue(':marca', $auto->marca, PDO::PARAM_STR);
            $consulta->bindValue(':precio', $auto->precio, PDO::PARAM_INT);
            $consulta->bindValue(':modelo', $auto->modelo, PDO::PARAM_STR);
            $consulta->bindValue(':id', $auto->id, PDO::PARAM_STR);
            $consulta->execute();
            
            if($consulta->rowCount() > 0) 
            {
                $jsonRespuesta->exito = true;
                $jsonRespuesta->mensaje = "Auto modificado.";
                $newResponse = $response->withJson($jsonRespuesta, 200);
            }
            else
            {
                $jsonRespuesta->exito = false;
                $jsonRespuesta->mensaje = "Ocurrió un error al intentar modificar el auto.";
                $newResponse = $response->withJson($jsonRespuesta, 418);
            }
        }
        else
        {
            $jsonRespuesta->exito = false;
            $jsonRespuesta->mensaje = $user->apellido." ".$user->nombre." se quiso pasar de listo modificando un auto.";
            
            $newResponse = $response->withJson($jsonRespuesta, 418);
        }

        return $newResponse;
    }



}